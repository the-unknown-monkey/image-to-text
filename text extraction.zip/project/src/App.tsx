import React, { useState } from 'react';
import { Upload, FileText } from 'lucide-react';

function App() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [extractedText, setExtractedText] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const imageUrl = URL.createObjectURL(file);
      setSelectedImage(imageUrl);
      setExtractedText('');
    }
  };

  const handleExtractText = async () => {
    setIsLoading(true);
    // TODO: Implement Google AI Studio API integration
    // This is where you'll make the API call to Google AI Studio
    // For now, we'll just simulate a delay
    setTimeout(() => {
      setExtractedText('Sample extracted text will appear here once you integrate the Google AI Studio API.');
      setIsLoading(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-4xl mx-auto space-y-8">
        <h1 className="text-3xl font-bold text-gray-800 text-center">
          Image Text Extractor
        </h1>

        {/* Image Upload Section */}
        <div className="bg-white p-8 rounded-lg shadow-md">
          <div className="space-y-4">
            <label 
              htmlFor="image-upload"
              className="block w-full border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-blue-500 transition-colors"
            >
              <Upload className="mx-auto h-12 w-12 text-gray-400" />
              <span className="mt-2 block text-sm font-medium text-gray-600">
                Click to upload an image or drag and drop
              </span>
              <input
                id="image-upload"
                type="file"
                className="hidden"
                accept="image/*"
                onChange={handleImageUpload}
              />
            </label>

            {selectedImage && (
              <div className="mt-4">
                <img
                  src={selectedImage}
                  alt="Selected"
                  className="max-h-96 mx-auto rounded-lg shadow-md"
                />
              </div>
            )}

            <button
              onClick={handleExtractText}
              disabled={!selectedImage || isLoading}
              className={`w-full py-3 px-4 rounded-md flex items-center justify-center space-x-2 ${
                !selectedImage || isLoading
                  ? 'bg-gray-300 cursor-not-allowed'
                  : 'bg-blue-600 hover:bg-blue-700'
              } text-white font-medium transition-colors`}
            >
              <FileText className="h-5 w-5" />
              <span>{isLoading ? 'Extracting...' : 'Extract the Text'}</span>
            </button>
          </div>
        </div>

        {/* Extracted Text Section */}
        <div className="bg-white p-8 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4 text-gray-800">
            Extracted Text
          </h2>
          <div className="bg-gray-50 rounded-lg p-4 min-h-[200px]">
            {extractedText ? (
              <p className="text-gray-700 whitespace-pre-wrap">{extractedText}</p>
            ) : (
              <p className="text-gray-500 italic">
                Extracted text will appear here after processing the image
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;